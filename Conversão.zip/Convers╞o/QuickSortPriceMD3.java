package Conversão;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuickSortPriceMD3 {
    private static final String INPUT_CSV = "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/games.csv";

    public static void main(String[] args) throws IOException, CsvException {
        List<String[]> rows = readCsv(INPUT_CSV);
        List<Game> games = convertToGames(rows);

        // Melhor caso: já ordenado
        quickSort(games, 0, games.size() - 1);
        writeCsv(games, "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/OrdenacaoPreco/games_price_quickSortMediana3_melhorCaso.csv");

        // Médio caso: embaralhado
        Collections.shuffle(games);
        quickSort(games, 0, games.size() - 1);
        writeCsv(games, "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/OrdenacaoPreco/games_price_quickSortMediana3_medioCaso.csv");

        // Pior caso: ordenado inversamente
        Collections.reverse(games);
        quickSort(games, 0, games.size() - 1);
        writeCsv(games, "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/OrdenacaoPreco/games_price_quickSortMediana3_piorCaso.csv");
    }

    private static List<String[]> readCsv(String filePath) throws IOException, CsvException {
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            List<String[]> allRows = reader.readAll();
            allRows.remove(0); // Remove the header
            return allRows;
        }
    }

    private static void writeCsv(List<Game> games, String outputFile) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(outputFile))) {
            writer.writeNext(new String[]{"AppID", "Name", "Price"}); // Write header
            for (Game game : games) {
                writer.writeNext(new String[]{game.appId, game.name, String.format("%.2f", game.price)});
            }
        }
    }

    private static List<Game> convertToGames(List<String[]> rows) {
        List<Game> games = new ArrayList<>();
        for (String[] row : rows) {
            try {
                double price = Double.parseDouble(row[6]);
                games.add(new Game(row[0], row[1], price));
            } catch (NumberFormatException e) {
                System.out.println("Error parsing price for game: " + row[1]);
            }
        }
        return games;
    }

    private static void quickSort(List<Game> games, int low, int high) {
        if (low < high) {
            int pi = partition(games, low, high);
            quickSort(games, low, pi - 1);
            quickSort(games, pi + 1, high);
        }
    }

    private static int partition(List<Game> games, int low, int high) {
        // Median of three
        int middle = low + (high - low) / 2;
        if (games.get(middle).price < games.get(low).price)
            Collections.swap(games, low, middle);
        if (games.get(high).price < games.get(low).price)
            Collections.swap(games, low, high);
        if (games.get(high).price < games.get(middle).price)
            Collections.swap(games, middle, high);

        Game pivot = games.get(middle);
        Collections.swap(games, middle, high); // Put pivot at the end

        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (games.get(j).price <= pivot.price) {
                i++;
                Collections.swap(games, i, j);
            }
        }
        Collections.swap(games, i + 1, high);
        return i + 1;
    }

    static class Game {
        String appId;
        String name;
        double price;

        public Game(String appId, String name, double price) {
            this.appId = appId;
            this.name = name;
            this.price = price;
        }
    }
}

