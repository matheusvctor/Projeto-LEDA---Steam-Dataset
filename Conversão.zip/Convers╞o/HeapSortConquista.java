package Conversão;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HeapSortConquista {
    private static final String INPUT_CSV = "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/games.csv"; // Caminho completo para leitura

    public static void main(String[] args) throws IOException, CsvException {
        List<String[]> rows = readCsv(INPUT_CSV);
        List<Game> games = convertToGames(rows);

        // Melhor caso: já ordenado de forma decrescente
        heapSort(games);
        writeCsv(games, "games_achievements_heapSort_melhorCaso.csv");

        // Médio caso: embaralhado
        Collections.shuffle(games);
        heapSort(games);
        writeCsv(games, "games_achievements_heapSort_medioCaso.csv");

        // Pior caso: ordenado de forma crescente
        Collections.sort(games, (a, b) -> Integer.compare(b.achievements, a.achievements)); // Ordena de forma crescente
        Collections.reverse(games); // Reverte para decrescente
        heapSort(games);
        writeCsv(games, "games_achievements_heapSort_piorCaso.csv");
    }

    private static List<String[]> readCsv(String filePath) throws IOException, CsvException {
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            List<String[]> allRows = reader.readAll();
            allRows.remove(0); // Remove cabeçalho
            return allRows;
        }
    }

    private static void writeCsv(List<Game> games, String outputFile) throws IOException {
        String outputFilePath = "C:/Users/mathe/Downloads/Projeto Steam Dataset/archive/OrdenacaoConquista/" + outputFile;
        try (CSVWriter writer = new CSVWriter(new FileWriter(outputFilePath))) {
            writer.writeNext(new String[]{"AppID", "Name", "Achievements"});
            for (Game game : games) {
                writer.writeNext(new String[]{game.appId, game.name, String.valueOf(game.achievements)});
            }
        }
    }

    private static List<Game> convertToGames(List<String[]> rows) {
        List<Game> games = new ArrayList<>();
        for (String[] row : rows) {
            try {
                int achievements = Integer.parseInt(row[25]); // Coluna de conquistas
                games.add(new Game(row[0], row[1], achievements));
            } catch (NumberFormatException e) {
                System.err.println("Erro ao converter conquistas para o jogo: " + row[1]);
            }
        }
        return games;
    }

    private static void heapSort(List<Game> games) {
        int n = games.size();

        // Construir heap (reorganizar o array)
        for (int i = n / 2 - 1; i >= 0; i--)
            heapify(games, n, i);

        // Um por um extrair um elemento do heap
        for (int i = n - 1; i > 0; i--) {
            // Mover a raiz atual para o fim
            Collections.swap(games, 0, i);

            // chamar max heapify na heap reduzida
            heapify(games, i, 0);
        }
    }

    // Para heapify uma subárvore enraizada no índice i.
    // n é o tamanho do heap
    private static void heapify(List<Game> games, int n, int i) {
        int largest = i; // Inicializar o maior como raiz
        int l = 2 * i + 1; // esquerda = 2*i + 1
        int r = 2 * i + 2; // direita = 2*i + 2

        // Se o filho esquerdo é maior do que a raiz
        if (l < n && games.get(l).achievements > games.get(largest).achievements)
            largest = l;

                // Se o filho direito é maior do que o maior até agora
                if (r < n && games.get(r).achievements > games.get(largest).achievements)
                largest = r;
    
            // Se o maior não é a raiz
            if (largest != i) {
                Collections.swap(games, i, largest);
    
                // Heapify recursivamente a subárvore afetada
                heapify(games, n, largest);
            }
        }
    
        static class Game {
            String appId;
            String name;
            int achievements;
    
            public Game(String appId, String name, int achievements) {
                this.appId = appId;
                this.name = name;
                this.achievements = achievements;
            }
        }
    }
    


